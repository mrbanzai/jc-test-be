<?php
// for our example to work in the command line, we're overriding the host
// (this is not necessary from web)
$_SERVER['HTTP_HOST'] = 'parallonjobs.com';

// include the library
$path = rtrim(dirname(__FILE__), DIRECTORY_SEPARATOR);
require_once($path . '/../libs/Client.php');

// you can initialize in one of two ways
$config = array(
    'apiBaseUrl' => 'http://local.jobcastle.com/api/',
    'publicKey' => '50f27ab87ceae988f43d8ca191159bfd673c87cf',
    'privateKey' => '63aace81abe7f536843834919cd7931bd9053149'
);

$client = new Skookum_Api_Client($config);

// or the second way...
$publicKey = '50f27ab87ceae988f43d8ca191159bfd673c87cf';
$privateKey = '63aace81abe7f536843834919cd7931bd9053149';

$client = new Skookum_Api_Client($config, $publicKey, $privateKey);

// retrieve the total number of categories
$numCategories = $client->get('/categories/count/');
echo 'The total number of categories:' . PHP_EOL;
var_dump($numCategories);

// retrieve all categories with their names in ascending order
$categories = $client->get('/categories/');
echo 'The first categories, defaulting to 25 per page ordered by name in ascending order:' . PHP_EOL;
var_dump($categories);

// retrieve all categories with their names in descending order
$categories = $client->get('/categories/', array('sortOrder' => 'DESC'));
echo 'The first categories, defaulting to 25 per page ordered by name in descending order:' . PHP_EOL;
var_dump($categories);

// example of retrieving a small subset of categories for pagination
$categories = $client->get('/categories/', array('perPage' => 5));
echo 'The first 5 categories:' . PHP_EOL;
var_dump($categories);

//==================
// RETRIEVAL BY CITY
//==================

// retrieve the total number of cities
$numCities = $client->get('/cities/count/');
echo 'The total number of cities:' . PHP_EOL;
var_dump($numCities);

// retrieve cities with their names in ascending order
$cities = $client->get('/cities/');
echo 'The first cities, defaulting to 25 per page ordered by name in ascending order:' . PHP_EOL;
var_dump($cities);

// retrieve cities with their names in descending order
$cities = $client->get('/cities/', array('sortOrder' => 'DESC'));
echo 'The first cities, defaulting to 25 per page ordered by name in descending order:' . PHP_EOL;
var_dump($cities);

// retrieve cities with their counts in descending order
$cities = $client->get('/cities/', array('orderBy' => 'count', 'sortOrder' => 'DESC'));
echo 'The first cities, defaulting to 25 per page ordered by count in descending order:' . PHP_EOL;
var_dump($cities);

// example of retrieving a small subset of cities for pagination
$cities = $client->get('/cities/', array('perPage' => 5));
echo 'The first 5 cities:' . PHP_EOL;
var_dump($cities);

//==================
// RETRIEVAL BY STATE
//==================

// retrieve the total number of states
$numStates = $client->get('/states/count/');
echo 'The total number of states:' . PHP_EOL;
var_dump($numStates);

// retrieve states with their names in ascending order
$states = $client->get('/states/');
echo 'The first states, defaulting to 25 per page ordered by name in ascending order:' . PHP_EOL;
var_dump($states);

// retrieve states with their names in descending order
$states = $client->get('/states/', array('sortOrder' => 'DESC'));
echo 'The first states, defaulting to 25 per page ordered by name in descending order:' . PHP_EOL;
var_dump($states);

// retrieve states with their counts in descending order
$states = $client->get('/states/', array('orderBy' => 'count', 'sortOrder' => 'DESC'));
echo 'The first states, defaulting to 25 per page ordered by count in descending order:' . PHP_EOL;
var_dump($states);

// example of retrieving a small subset of states for pagination
$states = $client->get('/states/', array('perPage' => 5));
echo 'The first 5 states:' . PHP_EOL;
var_dump($states);

//======================
// RETRIEVAL BY SCHEDULE
//======================

// retrieve the total number of schedules
$numSchedules = $client->get('/schedules/count/');
echo 'The total number of schedules:' . PHP_EOL;
var_dump($numSchedules);

// retrieve schedules with their names in ascending order
$schedules = $client->get('/schedules/');
echo 'The first schedules, defaulting to 25 per page ordered by name in ascending order:' . PHP_EOL;
var_dump($schedules);

// retrieve schedules with their names in descending order
$schedules = $client->get('/schedules/', array('sortOrder' => 'DESC'));
echo 'The first schedules, defaulting to 25 per page ordered by name in descending order:' . PHP_EOL;
var_dump($schedules);

// retrieve schedules with their counts in descending order
$schedules = $client->get('/schedules/', array('orderBy' => 'count', 'sortOrder' => 'DESC'));
echo 'The first schedules, defaulting to 25 per page ordered by count in descending order:' . PHP_EOL;
var_dump($schedules);

// example of retrieving a small subset of schedules for pagination
$schedules = $client->get('/schedules/', array('perPage' => 5));
echo 'The first 5 schedules:' . PHP_EOL;
var_dump($schedules);
